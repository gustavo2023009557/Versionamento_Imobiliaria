package com.example.demo.UserDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadFotoDTO {
    private Integer imovelId;
    private Integer capa;
    private Integer ordem;
}